In the server Folder , you can run:

### `npm i`

### `npm start`

Server will run on port# 4000.

In the Client Folder , you can run:

### `npm i`

### `npm install --save --legacy-peer-deps @material-ui/core`

### `npm start`

client will be on port# 3000
