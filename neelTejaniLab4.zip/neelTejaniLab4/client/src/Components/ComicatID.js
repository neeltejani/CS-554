import { makeStyles, Typography } from "@material-ui/core";
import axios from "axios";
import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { Card, CardMedia, CardHeader, Button } from "@material-ui/core";
const useStyles = makeStyles({
  card: {
    maxWidth: 550,
    height: "auto",
    marginLeft: "auto",
    marginRight: "auto",
    borderRadius: 5,
    border: "1px solid #178577",
    boxShadow: "0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);",
  },
  titleHead: {
    borderBottom: "1px solid #178577",
    fontWeight: "bold",
  },
  grid: {
    flexGrow: 1,
    flexDirection: "row",
  },
  media: {
    height: "100%",
    width: "100%",
  },
  button: {
    color: "#178577",
    fontWeight: "bold",
    fontSize: 12,
  },
});
const Comic = () => {
  const classes = useStyles();
  const { id } = useParams();
  const navigate = useNavigate();
  const [comicDataatID, showcomicDataatID] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    async function fetchData() {
      console.log(`http://localhost:4000/comics/${id}`);
      try {
        const { data } = await axios.get(`http://localhost:4000/comics/${id}`);
        console.log(data);
        showcomicDataatID(data);
        setLoading(false);
      } catch (e) {
        return (window.location.href = "/Error");
      }
    }
    fetchData();
  }, [id]);
  const handleClick = () => {
    navigate(-1);
  };
  if (loading) {
    return (
      <div>
        <h2>Loading....</h2>
      </div>
    );
  } else {
    return (
      <Card className={classes.card} variant="outlined">
        <CardHeader className={classes.titleHead} title={comicDataatID.title} />

        <CardMedia
          className={classes.media}
          component="img"
          image={
            comicDataatID.thumbnail.path +
            "/portrait_incredible." +
            comicDataatID.thumbnail.extension
          }
          title="show image"
        />

        <hr></hr>
        <Typography variant="h6">CHARACTERS</Typography>
        {comicDataatID.characters.items.length > 0 ? (
          comicDataatID.characters.items.map((element) => {
            return (
              <li>
                <Typography variant="h9">{element.name}</Typography>
              </li>
            );
          })
        ) : (
          <Typography variant="h9">No Characters Found</Typography>
        )}
        <hr></hr>

        <Typography variant="h6">STORIES</Typography>
        {comicDataatID.stories.items.length > 0 ? (
          comicDataatID.stories.items.map((element) => {
            return (
              <li>
                <Typography color="textPrimary" variant="h9">
                  {element.name}
                </Typography>
                <Typography color="textPrimary" variant="h9">
                  {element.type}
                </Typography>
              </li>
            );
          })
        ) : (
          <Typography variant="h9">No Stories Found</Typography>
        )}
        <hr></hr>

        <Typography variant="h6">CREATORS</Typography>

        {comicDataatID.creators.items.map((element) => {
          return (
            <li>
              <Typography color="textPrimary" variant="h9">
                {element.name} - {element.role}
              </Typography>
            </li>
          );
        })}
        <hr></hr>
        <hr></hr>
        <Button variant="contained" onClick={handleClick}>
          <Typography variant="h6">BACK TO ALL SHOWS</Typography>
        </Button>
      </Card>
    );
  }
};

export default Comic;
