import axios from "axios";
import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import noImage from "../img/download.jpeg";

import {
  Button,
  Typography,
  makeStyles,
  Grid,
  Card,
  CardActionArea,
  CardMedia,
  CardContent,
} from "@material-ui/core";
import Search from "./Search";
const useStyles = makeStyles({
  card: {
    maxWidth: 250,
    height: "auto",
    marginLeft: "auto",
    marginRight: "auto",
    borderRadius: 5,
    border: "1px solid #178577",
    boxShadow: "0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);",
  },
  titleHead: {
    borderBottom: "1px solid #178577",
    fontWeight: "bold",
  },
  grid: {
    flexGrow: 1,
    flexDirection: "row",
  },
  media: {
    height: "100%",
    width: "100%",
  },
  button: {
    color: "#178577",
    fontWeight: "bold",
    fontSize: 12,
  },
});
const Comics = (props) => {
  const { pagenum } = useParams();
  const [comicsData, showComicsData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [lastPagenumber, setlastPagenumber] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchData, setSearchData] = useState(undefined);
  let classes = useStyles();
  let card = null;
  useEffect(() => {
    async function fetchData() {
      try {
        const { data } = await axios.get(
          `http://localhost:4000/api/comics/page/${pagenum}`
        );
        console.log(data);
        if (data.data.results.length === 0) {
          return (window.location.href = `/Error`);
        }
        showComicsData(data.data.results);
        setlastPagenumber(data.data.total / data.data.limit);
        console.log(lastPagenumber);
        setLoading(false);
      } catch (e) {
        return (window.location.href = "/Error");
      }
    }
    fetchData();
  }, [pagenum, lastPagenumber]);

  useEffect(() => {
    console.log("search useEffect fired");
    async function fetchData() {
      try {
        console.log(`in fetch searchTerm: ${searchTerm}`);
        const { data } = await axios.get(
          `http://localhost:4000/api/comics/search/${searchTerm}`
        );
        console.log(data.data.results);
        setSearchData(data.data.results);
        setLoading(false);
      } catch (e) {
        return (window.location.href = "/Error");
      }
    }
    if (searchTerm) {
      fetchData();
    }
  }, [searchTerm]);

  const searchValue = async (value) => {
    setSearchTerm(value);
  };

  function loadButtons() {
    if (pagenum <= 1) {
      return (
        <div>
          <Button type="button" onClick={nextPage}>
            <Typography variant="h1">Next</Typography>
          </Button>
        </div>
      );
    } else if (pagenum < lastPagenumber)
      return (
        <div>
          <Button type="button" onClick={previousPage}>
            <Typography variant="h1">Previous</Typography>
          </Button>
          &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;
          &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;
          &nbsp;&nbsp; &nbsp;&nbsp;
          <Button type="button" onClick={nextPage}>
            <Typography variant="h1">Next</Typography>
          </Button>
        </div>
      );
    else {
      return (
        <div>
          <Button type="button" onClick={previousPage}>
            <Typography variant="h1">Previous</Typography>
          </Button>
        </div>
      );
    }
  }
  const nextPage = () => {
    window.location.href = `/api/comics/page/${parseInt(pagenum) + 1}`;
  };
  const previousPage = () => {
    window.location.href = `/api/comics/page/${parseInt(pagenum) - 1}`;
  };

  const buildCard = (comic) => {
    return (
      <Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={comic.id}>
        <Card className={classes.card} variant="outlined">
          <CardActionArea>
            <Link to={`/comics/${comic.id}`}>
              <CardMedia
                className={classes.media}
                component="img"
                image={
                  comic.thumbnail &&
                  !comic.thumbnail.path.includes("image_not_available")
                    ? comic.thumbnail.path +
                      "/standard_xlarge." +
                      comic.thumbnail.extension
                    : noImage
                }
                title="show image"
              />

              <CardContent>
                <Typography
                  className={classes.titleHead}
                  gutterBottom
                  variant="h6"
                  component="h2"
                  color="textSecondary"
                >
                  {comic.title}
                </Typography>
              </CardContent>
            </Link>
          </CardActionArea>
        </Card>
      </Grid>
    );
  };

  if (searchTerm) {
    card =
      searchData &&
      searchData.map((element) => {
        return buildCard(element);
      });
  } else {
    card =
      comicsData &&
      comicsData.map((element) => {
        return buildCard(element);
      });
  }
  if (loading) {
    return (
      <div>
        <h2>Loading....</h2>
      </div>
    );
  } else {
    return (
      <div>
        <Search searchValue={searchValue} />
        <br />
        <br />
        {loadButtons()}
        <Grid container className={classes.grid} spacing={5}>
          {card}
        </Grid>
      </div>
    );
  }
};

export default Comics;
