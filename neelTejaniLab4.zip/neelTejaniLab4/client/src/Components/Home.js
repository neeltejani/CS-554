import React from "react";
import "../App.css";
import { Link } from "react-router-dom";
const Home = () => {
  return (
    <div>
      <h1>
        The Marvel API allows developers everywhere to access information about
        Marvel's vast library of characters,comics,stories to 70 years ago.
      </h1>
      <div>
        <Link to={"api/characters/page/1"}>Characters</Link>
        &emsp;&emsp;
        <Link to={"api/comics/page/1"}>Comics</Link>
        &emsp;&emsp;
        <Link to={"api/stories/page/1"}>Stories</Link>
        &emsp;&emsp;
      </div>
    </div>
  );
};

export default Home;
