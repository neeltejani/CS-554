import axios from "axios";
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

import {
  Typography,
  makeStyles,
  Grid,
  Card,
  CardActionArea,
  CardMedia,
  CardContent,
  Button,
} from "@material-ui/core";

const useStyles = makeStyles({
  card: {
    maxWidth: 250,
    height: "auto",
    marginLeft: "auto",
    marginRight: "auto",
    borderRadius: 5,
    border: "1px solid #178577",
    boxShadow: "0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);",
  },
  titleHead: {
    borderBottom: "1px solid #178577",
    fontWeight: "bold",
  },
  grid: {
    flexGrow: 1,  
    flexDirection: "row",
  },
  media: {
    height: "100%",
    width: "100%",
  },
  button: {
    color: "#178577",
    fontWeight: "bold",
    fontSize: 12,
  },
});

const History = (props) => {
  const [historyData, setHistoryData] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  let classes = useStyles();
  let card = null;
  useEffect(() => {
    async function fetchData() {
      try {
        const { data } = await axios.get(
          `http://localhost:4000/api/characters/history`
        );
        setHistoryData(data);
        setLoading(false);
      } catch (e) {
        setLoading(false);
        return (window.location.href = "/Error");
      }
    }
    fetchData();
  }, []);
  const buildCard = (character) => {
    return (
      <Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={character.id}>
        <Card className={classes.card} variant="outlined">
          <CardActionArea>
            <Link to={`/characters/${character.id}`}>
              <CardMedia
                className={classes.media}
                component="img"
                image={
                  character.thumbnail.path +
                  "/standard_xlarge." +
                  character.thumbnail.extension
                }
                title="show image"
              />

              <CardContent>
                <Typography
                  className={classes.titleHead}
                  gutterBottom
                  variant="h6"
                  component="h2"
                  color="textSecondary"
                >
                  {character.name}
                </Typography>
              </CardContent>
            </Link>
          </CardActionArea>
        </Card>
      </Grid>
    );
  };
  card =
    historyData &&
    historyData.map((element) => {
      return buildCard(element);
    });
  const handleClick = () => {
    navigate(-1);
  };
  if (loading) {
    return (
      <div>
        <h2>Loading....</h2>
      </div>
    );
  } else {
    return (
      <div>
        <Button variant="contained" onClick={handleClick}>
          <Typography variant="h1">BACK TO ALL SHOWS</Typography>
        </Button>
        <br></br>
        <br></br>
        <Grid container spacing={3}>
          {card}
        </Grid>
      </div>
    );
  }
};

export default History;
