import axios from "axios";
import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import {
  Button,
  Typography,
  makeStyles,
  Grid,
  Card,
  CardActionArea,
  CardMedia,
  CardContent,
} from "@material-ui/core";
import noImage from "../img/download.jpeg";

import { Link } from "react-router-dom";
import Search from "./Search";
const useStyles = makeStyles({
  card: {
    maxWidth: 250,
    height: "auto",
    marginLeft: "auto",
    marginRight: "auto",
    borderRadius: 5,
    border: "1px solid #178577",
    boxShadow: "0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);",
  },
  titleHead: {
    borderBottom: "1px solid #178577",
    fontWeight: "bold",
  },
  grid: {
    flexGrow: 1,
    flexDirection: "row",
  },
  media: {
    height: "100%",
    width: "100%",
  },
  button: {
    color: "#178577",
    fontWeight: "bold",
    fontSize: 12,
  },
});

const Characters = (props) => {
  const { pagenum } = useParams();
  const [characterData, showCharacterData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchData, setSearchData] = useState(undefined);
  const [lastPagenumber, setlastPagenumber] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  let classes = useStyles();
  let card = null;
  useEffect(() => {
    async function fetchData() {
      try {
        const { data } = await axios.get(
          `http://localhost:4000/api/characters/page/${pagenum}`
        );
        if (data.data.results.length === 0) {
          return (window.location.href = `/Error`);
        }
        console.log(`result is ${data.data.results}`);
        showCharacterData(data.data.results);
        setlastPagenumber(data.data.total / data.data.limit);
        console.log(data.data.total);
        console.log(data.data.limit);
        console.log(lastPagenumber);
        setLoading(false);
      } catch (e) {
        return (window.location.href = "/Error");
      }
    }
    fetchData();
  }, [pagenum, lastPagenumber]);

  useEffect(() => {
    console.log("search useEffect fired");
    async function fetchData() {
      try {
        console.log(`in fetch searchTerm: ${searchTerm}`);
        const { data } = await axios.get(
          `http://localhost:4000/api/characters/search/${searchTerm}`
        );
        setSearchData(data.data.results);
        setLoading(false);
      } catch (e) {
        return (window.location.href = "/Error");
      }
    }
    if (searchTerm) {
      fetchData();
    }
  }, [searchTerm]);

  const searchValue = async (value) => {
    setSearchTerm(value);
  };
  function loadButtons() {
    if (pagenum <= 1) {
      return (
        <div>
          <Button type="button" onClick={nextPage}>
            <Typography variant="h2">Next</Typography>
          </Button>
        </div>
      );
    } else if (pagenum < lastPagenumber)
      return (
        <div>
          <Button type="button" onClick={previousPage}>
            <Typography variant="h2">Previous</Typography>
          </Button>
          &nbsp;&nbsp;
          <Button type="button" onClick={nextPage}>
            <Typography variant="h2">Next</Typography>
          </Button>
        </div>
      );
    else {
      return (
        <div>
          <Button type="button" onClick={previousPage}>
            <Typography variant="h2">Previous</Typography>
          </Button>
        </div>
      );
    }
  }
  const nextPage = () => {
    window.location.href = `/api/characters/page/${parseInt(pagenum) + 1}`;
  };
  const previousPage = () => {
    window.location.href = `/api/characters/page/${parseInt(pagenum) - 1}`;
  };
  const buildCard = (character) => {
    return (
      <Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={character.id}>
        <Card className={classes.card} variant="outlined">
          <CardActionArea>
            <Link to={`/characters/${character.id}`}>
              <CardMedia
                className={classes.media}
                component="img"
                image={
                  character.thumbnail &&
                  !character.thumbnail.path.includes("image_not_available")
                    ? character.thumbnail.path +
                      "/standard_xlarge." +
                      character.thumbnail.extension
                    : noImage
                }
                title="show image"
              />

              <CardContent>
                <Typography
                  className={classes.titleHead}
                  gutterBottom
                  variant="h6"
                  component="h2"
                  color="textSecondary"
                >
                  {character.name}
                </Typography>
              </CardContent>
            </Link>
          </CardActionArea>
        </Card>
      </Grid>
    );
  };
  if (searchTerm) {
    card =
      searchData &&
      searchData.map((element) => {
        return buildCard(element);
      });
  } else {
    card =
      characterData &&
      characterData.map((element) => {
        return buildCard(element);
      });
  }

  if (loading) {
    return (
      <div>
        <h2>Loading....</h2>
      </div>
    );
  } else {
    return (
      <div>
        <div>
          <Search searchValue={searchValue} />
          &nbsp;
          <Link to={"/characters/history"}>
            <Typography variant="h1">History</Typography>
          </Link>
          <br />
        </div>
        {loadButtons()}

        <br></br>
        <Grid container className={classes.grid} spacing={5}>
          {card}
        </Grid>
      </div>
    );
  }
};

export default Characters;
