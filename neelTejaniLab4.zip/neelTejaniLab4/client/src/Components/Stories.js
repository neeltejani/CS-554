import axios from "axios";
import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import {
  Button,
  Typography,
  makeStyles,
  Grid,
  Card,
  CardActionArea,
  CardContent,
  CardMedia,
} from "@material-ui/core";
import noImage from "../img/download.jpeg";
import Search from "./Search";
const useStyles = makeStyles({
  card: {
    maxWidth: 250,
    height: "auto",
    marginLeft: "auto",
    marginRight: "auto",
    borderRadius: 5,
    border: "1px solid #178577",
    boxShadow: "0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);",
  },
  titleHead: {
    borderBottom: "1px solid #178577",
    fontWeight: "bold",
  },
  grid: {
    flexGrow: 1,
    flexDirection: "row",
  },
  media: {
    height: "100%",
    width: "100%",
  },
  button: {
    color: "#178577",
    fontWeight: "bold",
    fontSize: 12,
  },
});

const Stories = (props) => {
  const { pagenum } = useParams();
  const [storiesData, showstoriesData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [lastPagenumber, setlastPagenumber] = useState(0);
  const [searchData, setSearchData] = useState(undefined);
  const [searchTerm, setSearchTerm] = useState("");
  let classes = useStyles();
  let card = null;

  useEffect(() => {
    async function fetchData() {
      try {
        const { data } = await axios.get(
          `http://localhost:4000/api/stories/page/${pagenum}`
        );
        console.log(data);
        if (data.data.results.length === 0) {
          return (window.location.href = `/Error`);
        }
        showstoriesData(data.data.results);
        setlastPagenumber(data.data.total / data.data.limit);
        console.log(lastPagenumber);
        setLoading(false);
      } catch (e) {
        return (window.location.href = "/Error");
      }
    }
    fetchData();
  }, [pagenum, lastPagenumber]);

  useEffect(() => {
    console.log("search useEffect fired");
    async function fetchData() {
      try {
        console.log(`in fetch searchTerm: ${searchTerm}`);
        const { data } = await axios.get(
          `http://localhost:4000/api/stories/search/${searchTerm}`
        );
        setSearchData(data.data.results);
        setLoading(false);
      } catch (e) {
        return (window.location.href = "/Error");
      }
    }
    if (searchTerm) {
      fetchData();
    }
  }, [searchTerm]);

  const searchValue = async (value) => {
    setSearchTerm(value);
  };
  const nextPage = () => {
    window.location.href = `/api/stories/page/${parseInt(pagenum) + 1}`;
  };
  const previousPage = () => {
    window.location.href = `/api/stories/page/${parseInt(pagenum) - 1}`;
  };

  const buildCard = (story) => {
    return (
      <Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={story.id}>
        <Card className={classes.card} variant="outlined">
          <CardActionArea>
            <Link to={`/stories/${story.id}`}>
              <CardMedia
                className={classes.media}
                component="img"
                image={noImage}
                title="show image"
              />
              <CardContent>
                <Typography
                  className={classes.titleHead}
                  gutterBottom
                  variant="h6"
                  component="h2"
                  color="textSecondary"
                >
                  {story.title}
                </Typography>
              </CardContent>
            </Link>
          </CardActionArea>
        </Card>
      </Grid>
    );
  };
  if (searchTerm) {
    card =
      searchData &&
      searchData.map((element) => {
        return buildCard(element);
      });
  } else {
    card =
      storiesData &&
      storiesData.map((element) => {
        return buildCard(element);
      });
  }
  function loadButtons() {
    if (pagenum <= 1) {
      return (
        <div>
          <Button type="button" onClick={nextPage}>
            <Typography variant="h1">Next</Typography>
          </Button>
        </div>
      );
    } else if (pagenum < lastPagenumber)
      return (
        <div>
          <Button type="button" onClick={previousPage}>
            <Typography variant="h1">Previous</Typography>
          </Button>
          &nbsp;&nbsp;
          <Button type="button" onClick={nextPage}>
            <Typography variant="h1">Next</Typography>
          </Button>
        </div>
      );
    else {
      return (
        <div>
          <Button type="button" onClick={previousPage}>
            <Typography variant="h1">Previous</Typography>
          </Button>
        </div>
      );
    }
  }
  if (loading) {
    return (
      <div>
        <h2>Loading....</h2>
      </div>
    );
  } else {
    return (
      <div>
        <Search searchValue={searchValue} />
        <br />
        <br />
        {loadButtons()}
        <Grid container className={classes.grid} spacing={5}>
          {card}
        </Grid>
      </div>
    );
  }
};

export default Stories;
