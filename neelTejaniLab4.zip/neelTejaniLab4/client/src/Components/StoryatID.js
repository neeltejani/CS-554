import axios from "axios";
import { makeStyles } from "@material-ui/core";
import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { Button, Typography, Card, CardHeader } from "@material-ui/core";
const useStyles = makeStyles({
  card: {
    maxWidth: 550,
    height: "auto",
    marginLeft: "auto",
    marginRight: "auto",
    borderRadius: 5,
    border: "1px solid #178577",
    boxShadow: "0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);",
  },
  titleHead: {
    borderBottom: "1px solid #178577",
    fontWeight: "bold",
  },
  grid: {
    flexGrow: 1,
    flexDirection: "row",
  },
  media: {
    height: "100%",
    width: "100%",
  },
  button: {
    color: "#178577",
    fontWeight: "bold",
    fontSize: 12,
  },
});
const Story = () => {
  const classes = useStyles();
  const navigate = useNavigate();
  const { id } = useParams();
  const [storyDataatID, showstoryDataatID] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    async function fetchData() {
      try {
        const { data } = await axios.get(`http://localhost:4000/stories/${id}`);
        console.log(data);
        showstoryDataatID(data);
        setLoading(false);
      } catch (e) {
        return (window.location.href = "/Error");
      }
    }
    fetchData();
  }, [id]);
  const handleClick = () => {
    navigate(-1);
  };
  if (loading) {
    return (
      <div>
        <h2>Loading....</h2>
      </div>
    );
  } else {
    return (
      <Card className={classes.card} variant="outlined">
        <Typography variant="h6">TITLE</Typography>
        <CardHeader className={classes.titleHead} title={storyDataatID.title} />

        <Typography variant="h6">SERIES</Typography>
        {storyDataatID.series.items.length > 0 ? (
          storyDataatID.series.items.map((element) => {
            return (
              <li>
                <Typography color="textPrimary" variant="h9">
                  {element.name}
                </Typography>
              </li>
            );
          })
        ) : (
          <Typography>No Series Found</Typography>
        )}
        <hr></hr>

        <Typography variant="h6">COMICS</Typography>
        {storyDataatID.comics.items.length > 0 ? (
          storyDataatID.comics.items.map((element) => {
            return (
              <li>
                <Typography variant="h9">{element.name}</Typography>
              </li>
            );
          })
        ) : (
          <Typography variant="h9">No Comics Found</Typography>
        )}
        <hr></hr>
        <hr></hr>
        <Button variant="contained" onClick={handleClick}>
          <Typography variant="h6">BACK TO ALL SHOWS</Typography>
        </Button>
      </Card>
    );
  }
};

export default Story;
