import React from "react";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Characters from "./Components/Characters";
import CharacterByID from "./Components/CharacterByID";
import ComicatID from "./Components/ComicatID";
import Stories from "./Components/Stories";
import Comics from "./Components/Comics";
import StoryatID from "./Components/StoryatID";
import History from "./Components/History";
import Home from "./Components/Home";
import Error from "./Components/Error";
import Axios from "axios";
import logo from "./img/logo.jpg";
import { Link } from "react-router-dom";
const App = () => {
  Axios({
    method: "GET",
    url: "http://localhost:4000/",
    headers: {
      "Content-Type": "application/json",
    },
  }).then((res) => {
    console.log(res.data.message);
  });
  return (
    <BrowserRouter>
      <div className="App">
        <div className="App">
          <header className="App-header">
            <Link to={"/"}>
              <img src={logo} className="App-logo" alt="logo" />
            </Link>
          </header>
          <br />
          <br />
          <div className="App-body">
            <Routes>
              <Route exact path="/" element={<Home />} />
              <Route exact path="*" element={<Error />} />
              <Route exact path="/Error" element={<Error />} />
              <Route exact path="/characters/history" element={<History />} />
              <Route exact path="/stories/:id" element={<StoryatID />} />
              <Route exact path="/comics/:id" element={<ComicatID />} />
              <Route exact path="/characters/:id" element={<CharacterByID />} />
              <Route
                exact
                path="/api/characters/page/:pagenum"
                element={<Characters />}
              />
              <Route
                exact
                path="/api/comics/page/:pagenum"
                element={<Comics />}
              />
              <Route
                exact
                path="/api/stories/page/:pagenum"
                element={<Stories />}
              />
            </Routes>
          </div>
        </div>
      </div>
    </BrowserRouter>
  );
};

export default App;
